// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/chemistry_core.md, section "lib.rs"
// ============================================================================
//! chemistry_core — Unity FFI simulation library.
//!
//! ## Rust owns the atom array
//!
//! `SimContext` owns the atom storage itself now — atoms are spawned and
//! despawned through the FFI surface below, not passed in as a pointer
//! each call. This is deliberate: for Rust to actually be the source of
//! truth for atom identity (not just bookkeeping, but *enforcing* it),
//! and for this crate to work unmodified in a non-DOTS engine with zero
//! concept of a stable entity ID, the array has to live here.
//!
//! ## AtomState layout (C-compatible, 48 bytes)
//!
//! ```text
//!  offset  field           type
//!  ------  -----           ----
//!   0      position        [f32; 3]   world-space (Angstroms)
//!  12      velocity        [f32; 3]
//!  24      force           [f32; 3]   accumulated this frame, cleared per step
//!  36      mass            f32        atomic mass (amu)
//!  40      radius          f32        van der Waals radius (pm)
//!  44      atomic_number   i32        element Z — LJ param lookup key
//! ```
//!
//! ## AtomHandle layout (C-compatible, 8 bytes)
//!
//! ```text
//!  offset  field        type
//!  ------  -----        ----
//!   0      index        u32
//!   4      generation   u32
//! ```
//!
//! Chemistry_core's own type, not `mid_collections::GenerationalIndex`
//! directly — that type isn't `#[repr(C)]` (no layout guarantee across
//! FFI) and deliberately has no public constructor from raw parts (it can
//! only ever be *held*, obtained from `GenerationalIndexAllocator::allocate`,
//! never synthesized) — by design, so nothing can forge a handle. `AtomHandle`
//! is what actually crosses the FFI boundary; converted to/from the real
//! `GenerationalIndex` only inside Rust, by comparing against a handle this
//! crate already legitimately obtained, never by constructing one from the
//! raw ints C# sends back. Same reasoning `bevy_ecs::Entity` uses for being
//! `#[repr(C, align(8))]` in the first place — checked against the real
//! source, not assumed.
//!
//! ## Usage from C#
//!
//! ```csharp
//! FFIBridge.ValidateStructSizes();               // call once in Awake
//! IntPtr ctx = FFIBridge.chem_context_create(10.0f);
//! AtomHandle h = FFIBridge.chem_spawn_atom(ctx, 1, 0f, 0f, 0f); // Z=1 (hydrogen)
//! FFIBridge.chem_init(ctx, 300.0f, 42UL);
//! // per frame:
//! FFIBridge.chem_step(ctx, Time.deltaTime, 10.0f); // dt is femtoseconds, not
//!                                                   // seconds — see chem_step's
//!                                                   // own doc before wiring this
//!                                                   // straight to Time.deltaTime
//! IntPtr atoms = FFIBridge.chem_atoms_ptr(ctx);   // re-fetch every frame, don't cache
//! int n = FFIBridge.chem_atom_count(ctx);
//! // ... draw n AtomState structs starting at `atoms` ...
//! FFIBridge.chem_despawn_atom(ctx, h);
//! // on teardown (e.g. OnDestroy):
//! FFIBridge.chem_context_destroy(ctx);
//! ```
//!
//! `chem_atoms_ptr`'s array order is **not** stable across despawns
//! (swap-remove keeps the live set dense) — fine for "draw N points
//! somewhere" (this is a `GraphicsBuffer` + `DrawMesh` billboard renderer,
//! no per-atom GameObjects, so nothing needs a stable array slot to track
//! a specific atom across frames), not fine for "this array position is
//! always atom #47." Use `AtomHandle` + `chem_get_atom` for that.

mod simulation;
mod spatial_hash;
mod element_data;
mod fx_hash;

pub use simulation::*;
pub use element_data::{ElementParams, params, reactivity_index, bond_strength, make_atom, register_element, is_element_registered, unregister_element, clear_custom_elements};

/// FFI-safe atom handle. See module docs for why this exists instead of
/// passing `mid_collections::GenerationalIndex` directly.
#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AtomHandle {
    pub index: u32,
    pub generation: u32,
}

/// C-compatible atom state. Must match C# `AtomData` exactly.
/// Verified at compile time (48 bytes) and at runtime via `chem_struct_size()`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct AtomState {
    pub position:      [f32; 3],   //  0
    pub velocity:      [f32; 3],   // 12
    pub force:         [f32; 3],   // 24
    pub mass:          f32,         // 36
    pub radius:        f32,         // 40
    pub atomic_number: i32,         // 44
}

const _: () = assert!(core::mem::size_of::<AtomState>() == 48);
const _: () = assert!(core::mem::size_of::<AtomHandle>() == 8);

/// Rest length and current live separation of one bond edge — what C#
/// needs to draw a stick between two bonded atoms, or show one straining
/// before it snaps. See `chem_bond_geometry_at`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct BondGeometry {
    pub equilibrium_length: f32,   //  0
    pub current_length:     f32,   //  4
}

const _: () = assert!(core::mem::size_of::<BondGeometry>() == 8);

/// Rest angle and current live angle of one angle triple centered at a
/// vertex atom, in **radians** — what C# needs to draw/animate an angle
/// bend, or check how strained it is. Same role `BondGeometry` plays for
/// a bond edge. See `chem_angle_geometry_at`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct AngleGeometry {
    pub equilibrium_angle: f32,   //  0
    pub current_angle:     f32,   //  4
}

const _: () = assert!(core::mem::size_of::<AngleGeometry>() == 8);

/// One live, deduplicated bond edge, flattened for zero-copy bulk
/// consumption via `chem_bonds_ptr` — sits alongside the existing
/// per-bond `chem_bond_partner_at`/`chem_bond_geometry_at` accessors
/// rather than replacing them (a handful of one-off lookups is fine
/// either way; this is for "walk every live bond, every frame," which
/// those weren't built for).
///
/// `atom_a_index`/`atom_b_index` are dense-array **positions** — the
/// same indices `chem_atoms_ptr`'s own array uses, not `AtomHandle`s —
/// so a caller that already holds that array (every renderer does)
/// indexes straight into it with zero further FFI calls. Same "re-fetch
/// every frame, don't cache across a frame boundary" contract
/// `chem_atoms_ptr`/`chem_handles_ptr` already carry: a spawn/despawn/
/// step between one `chem_bonds_ptr` call and the next can move these
/// positions.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct BondRecord {
    pub atom_a_index:      u32,   //  0
    pub atom_b_index:      u32,   //  4
    pub equilibrium_length: f32,  //  8
    pub current_length:     f32,  // 12
}

const _: () = assert!(core::mem::size_of::<BondRecord>() == 16);

/// One bond-topology change a `chem_step` call produced — a bond that
/// formed, broke, or had its `order` change (an upgrade from single to
/// double, say). See `chem_take_bond_events`.
///
/// `atom_a_index`/`atom_b_index` are dense-array positions, same
/// "re-fetch every frame" contract `BondRecord` already carries — safe
/// here because nothing inside `chem_step` despawns an atom (only an
/// explicit `chem_despawn_atom` call does), so positions stay stable
/// across everything one `chem_step` call (or several, before the next
/// `chem_take_bond_events`) can produce.
///
/// `kind`: `0` = Formed, `1` = Broken, `2` = OrderChanged. `order` is
/// the bond's order after the change for Formed/OrderChanged (always
/// `1` for a fresh Formed — see `BondParams.max_bond_order`'s own doc
/// on why upgrades are opt-in), and the order it held right before
/// breaking for Broken (not "meaningless" — a snapped triple bond is a
/// different visual/gameplay beat than a snapped single one).
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct BondEvent {
    pub atom_a_index: u32, //  0
    pub atom_b_index: u32, //  4
    pub kind:         u8,  //  8
    pub order:        u8,  //  9
}

const _: () = assert!(core::mem::size_of::<BondEvent>() == 12);

// ── FFI surface ───────────────────────────────────────────────────────────────

/// Create a persistent simulation context: owns the atom array, the
/// spatial hash grid, and the scratch buffers the force kernels need.
/// `cutoff_hint` just sizes the initial grid — passing 0.0 is fine,
/// `chem_step` falls back to 10.0 either way.
///
/// Create once (e.g. in Awake), reuse for the lifetime of the simulation,
/// free exactly once with `chem_context_destroy` when done (e.g. OnDestroy).
#[no_mangle]
pub extern "C" fn chem_context_create(cutoff_hint: f32) -> *mut SimContext {
    Box::into_raw(Box::new(SimContext::new(cutoff_hint)))
}

/// Frees a context created by `chem_context_create`, and every atom still
/// alive in it. Passing null is a no-op. Never call this twice on the same
/// pointer, and never touch the pointer again afterward — same rules as
/// any C `free()`.
#[no_mangle]
pub unsafe extern "C" fn chem_context_destroy(ctx: *mut SimContext) {
    if !ctx.is_null() {
        drop(Box::from_raw(ctx));
    }
}

/// Spawn one atom of element `atomic_number` at `(x, y, z)`. Mass and
/// (rendering) radius are sourced from `element_data`'s table
/// automatically — same `make_atom` builder used internally. Returns a
/// handle valid until the atom is despawned.
#[no_mangle]
pub unsafe extern "C" fn chem_spawn_atom(
    ctx:           *mut SimContext,
    atomic_number: i32,
    x: f32, y: f32, z: f32,
) -> AtomHandle {
    let ctx = &mut *ctx;
    simulation::spawn_atom(ctx, atomic_number, [x, y, z])
}

/// Despawn an atom by handle. Returns `false` if the handle is stale
/// (already despawned, or from a different context) rather than crashing
/// — always check the return value if it matters to the caller.
#[no_mangle]
pub unsafe extern "C" fn chem_despawn_atom(ctx: *mut SimContext, handle: AtomHandle) -> bool {
    let ctx = &mut *ctx;
    simulation::despawn_atom(ctx, handle)
}

/// Current number of live atoms in the context.
#[no_mangle]
pub unsafe extern "C" fn chem_atom_count(ctx: *const SimContext) -> i32 {
    let ctx = &*ctx;
    simulation::atom_count(ctx) as i32
}

/// Copy one atom's current state into `out` by handle. Returns `false`
/// (and leaves `out` untouched) if the handle is stale.
#[no_mangle]
pub unsafe extern "C" fn chem_get_atom(
    ctx:    *const SimContext,
    handle: AtomHandle,
    out:    *mut AtomState,
) -> bool {
    let ctx = &*ctx;
    match simulation::get_atom(ctx, handle) {
        Some(a) => { *out = a; true }
        None => false,
    }
}

/// Read-only pointer into Rust's own dense atom array — for zero-copy
/// rendering. Valid only until the next `chem_spawn_atom`/
/// `chem_despawn_atom`/`chem_step` call on this context (a spawn can
/// reallocate, a despawn reorders via swap-remove) — re-fetch every
/// frame, never cache across a frame boundary.
#[no_mangle]
pub unsafe extern "C" fn chem_atoms_ptr(ctx: *const SimContext) -> *const AtomState {
    let ctx = &*ctx;
    simulation::atoms_ptr(ctx)
}

/// Read-only pointer into a dense `AtomHandle` array, same order and
/// same length as `chem_atoms_ptr`'s (index `i` here is the same atom as
/// index `i` there) — for a caller that needs to walk every live atom's
/// identity (e.g. to then query bonds for each one), not just its
/// physical state. Same "re-fetch every frame" and "order not stable
/// across despawns" contract as `chem_atoms_ptr`. Unlike that one, this
/// takes `*mut`, not `*const` — it genuinely refreshes an internal
/// scratch buffer each call (`GenerationalIndex` isn't FFI-safe to
/// expose directly, so this exists at all instead of just being another
/// raw field pointer — see `simulation::refresh_handles_scratch`'s own
/// doc for why).
#[no_mangle]
pub unsafe extern "C" fn chem_handles_ptr(ctx: *mut SimContext) -> *const AtomHandle {
    let ctx = &mut *ctx;
    simulation::refresh_handles_scratch(ctx)
}

/// Initialise every currently-live atom's velocity from a Maxwell-
/// Boltzmann distribution at `temperature_k`, zero their force
/// accumulators. Call once after spawning your initial atoms.
#[no_mangle]
pub unsafe extern "C" fn chem_init(ctx: *mut SimContext, temperature_k: f32, seed: u64) {
    let ctx = &mut *ctx;
    simulation::init(ctx, temperature_k, seed);
}

/// Advance simulation by `dt` **femtoseconds**, not seconds — matches
/// `simulation::step`'s own doc comment and what `AMU_TO_EFF_MASS`
/// (amu -> eV*fs^2/A^2) requires dimensionally for `F = ma` to balance.
/// An earlier version of this comment said "seconds"; that was wrong.
/// `cutoff` = 0.0 uses 10.0 Angstroms.
#[no_mangle]
pub unsafe extern "C" fn chem_step(ctx: *mut SimContext, dt: f32, cutoff: f32) {
    let ctx = &mut *ctx;
    simulation::step(ctx, dt, cutoff);
}

/// Total kinetic energy of all currently-live atoms, in eV.
#[no_mangle]
pub unsafe extern "C" fn chem_kinetic_energy(ctx: *const SimContext) -> f32 {
    let ctx = &*ctx;
    simulation::kinetic_energy(ctx)
}

/// Current temperature estimate in Kelvin (from equipartition).
#[no_mangle]
pub unsafe extern "C" fn chem_temperature(ctx: *const SimContext) -> f32 {
    let ctx = &*ctx;
    simulation::temperature(ctx)
}

/// Is this atom currently bonded to anything? `false` for a stale handle,
/// not a crash.
#[no_mangle]
pub unsafe extern "C" fn chem_is_bonded(ctx: *const SimContext, handle: AtomHandle) -> bool {
    let ctx = &*ctx;
    simulation::is_bonded(ctx, handle)
}

/// How many bonds this atom currently holds. 0 for a stale handle or an
/// unbonded atom — same "nothing there" value either way, deliberately
/// not distinguished (matches `chem_is_bonded`'s existing "false either
/// way" contract for stale handles). Bonds are unbounded per atom now
/// (see `simulation` module docs) — this replaces the old single-partner
/// `chem_bond_partner`, which could only ever express "bonded to one
/// thing or not." Safe to change out from under nothing: `Runtime/Core`
/// hasn't been written against the old shape yet.
#[no_mangle]
pub unsafe extern "C" fn chem_bond_count(ctx: *const SimContext, handle: AtomHandle) -> i32 {
    let ctx = &*ctx;
    simulation::bond_count(ctx, handle) as i32
}

/// This atom's `index`-th bond partner (`0..chem_bond_count(...)`).
/// Returns `false` (and leaves `out` untouched) for a stale handle, an
/// unbonded atom, or `index >= chem_bond_count(...)` — all the same
/// "nothing there" case from the caller's side, deliberately not
/// distinguished. Iterate `0..chem_bond_count(ctx, handle)` to walk every
/// partner; order isn't semantically meaningful (formation order, not
/// distance or anything else), just stable within a single frame.
#[no_mangle]
pub unsafe extern "C" fn chem_bond_partner_at(
    ctx:    *const SimContext,
    handle: AtomHandle,
    index:  i32,
    out:    *mut AtomHandle,
) -> bool {
    let ctx = &*ctx;
    if index < 0 {
        return false;
    }
    match simulation::bond_partner_at(ctx, handle, index as usize) {
        Some(partner) => { *out = partner; true }
        None => false,
    }
}

/// Rest length and current live separation of this atom's `index`-th bond
/// edge (`0..chem_bond_count(...)`) — same indexing `chem_bond_partner_at`
/// already uses. Returns `false` (and leaves `out` untouched) for a stale
/// handle, an unbonded atom, or an out-of-range index — same "nothing
/// there" contract every other bond accessor here uses.
///
/// `current_length` is read straight from each atom's live
/// `AtomState.position` — the same field `chem_get_atom`/`chem_atoms_ptr`
/// already expose — so it's accurate as of whatever the caller's last
/// `chem_step` left it at, with no extra call needed just to refresh it.
///
/// Strain isn't computed here on purpose: `(current_length -
/// equilibrium_length) / equilibrium_length` is one line on the C# side,
/// and leaving it there keeps this accessor from baking in a "how should
/// a straining bond be visualized/thresholded" opinion the game side
/// hasn't settled yet.
#[no_mangle]
pub unsafe extern "C" fn chem_bond_geometry_at(
    ctx:    *const SimContext,
    handle: AtomHandle,
    index:  i32,
    out:    *mut BondGeometry,
) -> bool {
    let ctx = &*ctx;
    if index < 0 {
        return false;
    }
    match simulation::bond_geometry_at(ctx, handle, index as usize) {
        Some(geo) => { *out = geo; true }
        None => false,
    }
}

/// Read-only pointer into a flat, deduplicated snapshot of every live
/// bond edge — `*out_count` entries of `BondRecord` starting here,
/// rebuilt fresh on every call (see `simulation::refresh_bonds_scratch`),
/// same "re-fetch every frame, don't cache across a frame boundary"
/// contract `chem_atoms_ptr`/`chem_handles_ptr` already carry.
///
/// Exists specifically to replace a per-bond P/Invoke walk
/// (`chem_bond_count` + `chem_bond_partner_at` + `chem_get_atom` ×2 +
/// `chem_bond_geometry_at`, once per edge, every frame — `BondRenderer.cs`'s
/// prior approach, by its own doc comment's admission) with one bulk
/// fetch. `atom_a_index`/`atom_b_index` on each `BondRecord` are the same
/// dense-array positions `chem_atoms_ptr`'s own array uses — a caller
/// that already holds that array from this frame indexes straight into
/// it, no further FFI call needed per edge.
///
/// Pointer **and** count both come from this one call, not
/// `chem_bonds_ptr()` plus a separate `chem_bond_total_count()` — unlike
/// `chem_atom_count` (a stable, independently-readable field, safe to
/// call before or after `chem_atoms_ptr` in either order), the total
/// distinct-edge count only exists as a byproduct of the rebuild this
/// function performs. Splitting it into two calls would create a real
/// ordering hazard — call a hypothetical count function first and it
/// reports last frame's number — that this signature makes structurally
/// impossible instead of documenting away and hoping callers read it.
#[no_mangle]
pub unsafe extern "C" fn chem_bonds_ptr(ctx: *mut SimContext, out_count: *mut i32) -> *const BondRecord {
    let ctx = &mut *ctx;
    let ptr = simulation::refresh_bonds_scratch(ctx);
    *out_count = simulation::bond_total_count(ctx) as i32;
    ptr
}

/// Read-only pointer into every `BondEvent` (formed/broken/order-changed)
/// produced since the last call to *this specific function* — `*out_count`
/// entries starting here, then the underlying buffer is cleared for next
/// time (see `simulation::take_bond_events`'s own doc). Unlike
/// `chem_bonds_ptr` above (a fresh rebuild of current state, safe to call
/// as often as you like), this one **consumes** what it returns: call it
/// once per Unity frame, after every `chem_step` sub-step that frame, not
/// once per sub-step — calling it more than once per frame silently
/// splits one frame's events across two reads instead of losing anything,
/// but calling it zero times just lets events accumulate (harmlessly)
/// until the next call that does.
#[no_mangle]
pub unsafe extern "C" fn chem_take_bond_events(ctx: *mut SimContext, out_count: *mut i32) -> *const BondEvent {
    let ctx = &mut *ctx;
    let mut count = 0i32;
    let ptr = simulation::take_bond_events(ctx, &mut count);
    *out_count = count;
    ptr
}

/// How many angle triples this atom is currently the **vertex** of — an
/// atom needs >= 2 simultaneous bonds to be one (every *pair* of its
/// bonds forms one triple). 0 for a stale handle or an atom that isn't a
/// vertex right now, deliberately not distinguished — same "nothing
/// there" contract `chem_bond_count` already uses. Does **not** count
/// triples where this atom is only an *arm* — walking "every angle this
/// atom is touched by at all" isn't something this sim indexes (see
/// `AngleInfo`'s own doc for why); to find those, walk this atom's own
/// bond partners and check each one's `chem_angle_count`/
/// `chem_angle_arms_at` instead.
#[no_mangle]
pub unsafe extern "C" fn chem_angle_count(ctx: *const SimContext, handle: AtomHandle) -> i32 {
    let ctx = &*ctx;
    simulation::angle_count(ctx, handle) as i32
}

/// This atom's `index`-th angle triple's two arm atoms
/// (`0..chem_angle_count(...)`) — `handle` itself is always the vertex.
/// Returns `false` (leaving both out params untouched) for a stale
/// handle, a non-vertex atom, or an out-of-range index — same "nothing
/// there" contract every other accessor here uses. Order isn't
/// semantically meaningful (formation order), just stable within a
/// single frame — same caveat `chem_bond_partner_at` already carries.
#[no_mangle]
pub unsafe extern "C" fn chem_angle_arms_at(
    ctx:       *const SimContext,
    handle:    AtomHandle,
    index:     i32,
    out_arm_a: *mut AtomHandle,
    out_arm_b: *mut AtomHandle,
) -> bool {
    let ctx = &*ctx;
    if index < 0 {
        return false;
    }
    match simulation::angle_arms_at(ctx, handle, index as usize) {
        Some((a, b)) => { *out_arm_a = a; *out_arm_b = b; true }
        None => false,
    }
}

/// Rest angle and current live angle (both **radians**) of this atom's
/// `index`-th angle triple (`0..chem_angle_count(...)`) — same indexing
/// as `chem_angle_arms_at`. `current_angle` is computed live from
/// `ctx.atoms[..].position` — accurate as of whatever the caller's last
/// `chem_step` left it at, same "always current, no step-ordering
/// dependency" contract `chem_bond_geometry_at` already documents.
///
/// Strain isn't computed here either, same reasoning `chem_bond_geometry_at`
/// already gives for bonds: `current_angle - equilibrium_angle` is one
/// line on the C# side, and leaving it there keeps this accessor from
/// baking in a visualization/threshold opinion the game side hasn't
/// settled yet.
#[no_mangle]
pub unsafe extern "C" fn chem_angle_geometry_at(
    ctx:    *const SimContext,
    handle: AtomHandle,
    index:  i32,
    out:    *mut AngleGeometry,
) -> bool {
    let ctx = &*ctx;
    if index < 0 {
        return false;
    }
    match simulation::angle_geometry_at(ctx, handle, index as usize) {
        Some(geo) => { *out = geo; true }
        None => false,
    }
}

// ── Custom elements ──────────────────────────────────────────────────────
//
// Global, not per-SimContext — see `element_data::register_element`'s own
// doc for why. None of these five take a `ctx` pointer at all, unlike
// everything above; that's deliberate, not an oversight.

/// Register (or overwrite) a custom element at runtime — no Rust
/// recompile needed. See `element_data::register_element`'s own doc for
/// the full contract (real elements 1..=118 always rejected, negative
/// mass/radius/sigma always rejected, everything else accepted as-is).
#[no_mangle]
pub extern "C" fn chem_register_element(
    atomic_number: i32,
    mass_amu: f32,
    radius_vdw_pm: f32,
    lj_sigma_a: f32,
    lj_eps_ev: f32,
    electronegativity: f32,
    ionization_energy_kj_mol: f32,
    electron_affinity_kj_mol: f32,
) -> bool {
    element_data::register_element(
        atomic_number, mass_amu, radius_vdw_pm, lj_sigma_a, lj_eps_ev,
        electronegativity, ionization_energy_kj_mol, electron_affinity_kj_mol,
    )
}

/// True if `atomic_number` is either a real element or a previously
/// registered custom one — false only for something `chem_spawn_atom`
/// would silently give zero mass/radius to.
#[no_mangle]
pub extern "C" fn chem_is_element_registered(atomic_number: i32) -> bool {
    element_data::is_element_registered(atomic_number)
}

/// Remove one previously-registered custom element. No-op for a real
/// element's atomic number.
#[no_mangle]
pub extern "C" fn chem_unregister_element(atomic_number: i32) -> bool {
    element_data::unregister_element(atomic_number)
}

/// Clear every custom-registered element at once. Real elements are
/// never affected — there's nothing for this to clear there.
#[no_mangle]
pub extern "C" fn chem_clear_custom_elements() {
    element_data::clear_custom_elements();
}

// ── Bond-distance queries (pure, no context) ────────────────────────────────

/// The LJ equilibrium separation (`sigma * 2^(1/6)`) for a pair of atomic
/// numbers — same value `simulation::compute_bonds`' own Pass 2 uses as a
/// fresh bond's `equilibrium_length`. Takes no `SimContext`: safe to call
/// before either atom is spawned, e.g. to keep a spawn-time placement
/// outside the LJ repulsive core. An unregistered atomic number uses
/// `element_data::params`'s own zero-defaulted `ElementParams`, same as
/// everywhere else in this crate — check `chem_is_element_registered`
/// first if that distinction matters to the caller.
#[no_mangle]
pub extern "C" fn chem_bond_r_min(atomic_number_a: i32, atomic_number_b: i32) -> f32 {
    let pa = element_data::params(atomic_number_a);
    let pb = element_data::params(atomic_number_b);
    let (sigma, _eps) = element_data::combine(pa, pb);
    sigma * 2f32.powf(1.0 / 6.0)
}

// ── Containment bubble / multi-order bonding ────────────────────────────────

/// Suppress Pass 2 bond-formation/order-upgrade consideration for this
/// atom for `duration_fs` femtoseconds — pass `f32::INFINITY` for "until
/// `chem_clear_suppression`/`chem_clear_suppression_in_radius` explicitly
/// lifts it". The "electromagnetic stabilizing bubble" mechanic: keep two
/// reactants apart chemically (LJ repulsion/attraction is completely
/// unaffected — this only ever gates *new* bonding) until a designed
/// trigger fires. Returns `false` for a stale handle, `true` otherwise.
#[no_mangle]
pub unsafe extern "C" fn chem_suppress_atom(ctx: *mut SimContext, handle: AtomHandle, duration_fs: f32) -> bool {
    let ctx = &mut *ctx;
    simulation::suppress_atom(ctx, handle, duration_fs)
}

/// Lift suppression on one specific atom early — the "a trigger fired for
/// exactly this atom" case. Returns whether it was actually suppressed.
#[no_mangle]
pub unsafe extern "C" fn chem_clear_suppression(ctx: *mut SimContext, handle: AtomHandle) -> bool {
    let ctx = &mut *ctx;
    simulation::clear_suppression(ctx, handle)
}

/// Lift suppression on every currently-suppressed atom within `radius` of
/// `(x, y, z)` — "the bubble collapses here". Returns how many were
/// cleared.
#[no_mangle]
pub unsafe extern "C" fn chem_clear_suppression_in_radius(ctx: *mut SimContext, x: f32, y: f32, z: f32, radius: f32) -> i32 {
    let ctx = &mut *ctx;
    simulation::clear_suppression_in_radius(ctx, [x, y, z], radius)
}

/// Raise or lower the ceiling Pass 2 can upgrade an already-bonded pair's
/// order to (1-3, clamped; default `1` — upgrades off). See
/// `BondParams.max_bond_order`'s own doc for what this actually changes.
#[no_mangle]
pub unsafe extern "C" fn chem_set_max_bond_order(ctx: *mut SimContext, max_order: u8) {
    let ctx = &mut *ctx;
    simulation::set_max_bond_order(ctx, max_order);
}

/// `AtomState` size validation. Call from C# `ValidateStructSizes()`.
/// If this returns != 48, the struct layout is mismatched — fix before proceeding.
#[no_mangle]
pub extern "C" fn chem_struct_size() -> i32 {
    core::mem::size_of::<AtomState>() as i32
}

/// `AtomHandle` size validation, same idea as `chem_struct_size`. Should
/// always return 8.
#[no_mangle]
pub extern "C" fn chem_handle_size() -> i32 {
    core::mem::size_of::<AtomHandle>() as i32
}

/// `BondGeometry` size validation, same idea as `chem_struct_size`. Should
/// always return 8.
#[no_mangle]
pub extern "C" fn chem_bond_geometry_size() -> i32 {
    core::mem::size_of::<BondGeometry>() as i32
}

/// `AngleGeometry` size validation, same idea as `chem_struct_size`.
/// Should always return 8.
#[no_mangle]
pub extern "C" fn chem_angle_geometry_size() -> i32 {
    core::mem::size_of::<AngleGeometry>() as i32
}

/// `BondRecord` size validation, same idea as `chem_struct_size`. Should
/// always return 16.
#[no_mangle]
pub extern "C" fn chem_bond_record_size() -> i32 {
    core::mem::size_of::<BondRecord>() as i32
}

/// `BondEvent` size validation, same idea as `chem_struct_size`. Should
/// always return 12.
#[no_mangle]
pub extern "C" fn chem_bond_event_size() -> i32 {
    core::mem::size_of::<BondEvent>() as i32
}
